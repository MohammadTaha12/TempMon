snmpget -v 2c -c Cisco3750 localhost 1.3.6.1.2.1.1.3.0
snmpget -v 2c -c Cisco3750 localhost 1.3.6.1.2.1.47.1.1.1.1.2.1
snmpget -v 2c -c Juniper510048S localhost 1.3.6.1.4.1.2636.3.47.1.1.5.1.2.111.112.111.119.110.101.114
snmpget -v 2c -c Transmode localhost 1.3.6.1.2.1.1.1.0

exit 0
